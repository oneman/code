
#include "yodl.h"
#include "config.h"

void 
version ()
{
  fprintf (stderr, "Yodl " TOPLEVEL_VERSION "\n");
}

void 
usage ()
{
  version ();
  fprintf (stderr,
"Yet oneOther Document Language\n"
"Usage: yodl [OPTION]... [FILE]...\n"
"Convert to various documentation formats from FILE or <stdin>.\n"
"\n"
"Options:\n"
"  -D, --define=NAME    define NAME as symbol, same as DEFINESYMBOL(NAME)\n"
"  -d, --definemacro=NAME=EXPANSION\n"
"                       define NAME as macro expanding to EXPANSION\n"
"  -h, --help           this message\n"
"  -I, --include=DIR    use directory DIR for system-wide includes files\n"
"                         [" STD_INCLUDE "]\n"
"  -l, --live-data=NR   set \"live data\" policy to NR [0]:\n"
"                         allow live data:\n"
"                           0: never (the default)\n"
"                           1: only when confirmed\n"
"                           2: issuing warning\n"
"                           3: always\n"
"  -o, --output=FILE    send output to FILE instead of <stdout>\n"
"  -P, --preload=CMD    preload CMD\n"
"  -p, --max-pass=NR    set the maximum number of parsing passes to NR [%d]\n"
"  -t, --trace          trace generated output to <stderr> for each parsing pass\n"
"  -v, --verbose        increase verbosity (-vv...)\n"
"  -W, --warranty       show warranty and copyright\n"
"  -w, --warn           warn about redefinitions\n"
, DEFAULT_MAXPASS);

  exit (1);
}
