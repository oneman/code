
#include "yodl2html-post.h"

void 
tocclose (void)
{
  int
    i, new_toclevel;

  new_toclevel = (doctype == type_article ? TOC_SECTION : TOC_CHAPTER);

  i = cur_toclevel;
  while (i > new_toclevel)
    {
      output (outf, "</dl><p>\n");
      i--;
    }
}
