
#include "yodl.h"

void
gram_DUMMY ()
{
  char
   *list = gram_parlist (builtin_get (idx_DUMMY), 0);

  message (3, "%s\n", builtin_get (idx_DUMMY));
  free (list);
}
