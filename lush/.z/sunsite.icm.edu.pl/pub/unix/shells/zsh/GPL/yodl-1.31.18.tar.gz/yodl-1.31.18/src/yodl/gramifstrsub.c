

#include "yodl.h"

void
gram_IFSTRSUB ()
{
  char
   *str1, *str2, *truelist, *falselist;
  int
    res;

  str1 = gram_parlist (builtin_get (idx_IFSTRSUB), 0);
  message (3, "%s %s\n", builtin_get (idx_IFSTRSUB), str_short (str1));

  while (lextok == tok_space || lextok == tok_newline)
    lexer ();
  str2 = gram_parlist (builtin_get (idx_IFSTRSUB), 0);

  while (lextok == tok_space || lextok == tok_newline)
    lexer ();
  truelist = gram_parlist (builtin_get (idx_IFSTRSUB), 0);

  while (lextok == tok_space || lextok == tok_newline)
    lexer ();
  falselist = gram_parlist (builtin_get (idx_IFSTRSUB), 0);
  lexer_pushstr (lexbuf);

  if (!str1)
    {
      if (!str2 || !*str2)
	res = 1;
      else
	res = 0;
    }
  else if (!str1)
    res = 0;
  else
    res = (int) strstr (str1, str2);

  if (res)
    lexer_pushstr (truelist);
  else
    lexer_pushstr (falselist);

  lexer ();

  free (str1);
  free (str2);
  free (truelist);
  free (falselist);
}
