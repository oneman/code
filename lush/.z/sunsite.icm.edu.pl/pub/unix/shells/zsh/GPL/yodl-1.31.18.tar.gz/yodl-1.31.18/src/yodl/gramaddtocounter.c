
#include "yodl.h"

void
gram_ADDTOCOUNTER ()
{
  char
   *name, *addst;
  int
    addnr, index;

  name = gram_parlist (builtin_get (idx_ADDTOCOUNTER), 0);
  index = gram_findcounter (builtin_get (idx_ADDTOCOUNTER), name);
  addst = gram_parlist (builtin_get (idx_ADDTOCOUNTER), 0);
  addnr = gram_onenumber (builtin_get (idx_ADDTOCOUNTER), addst);

  message (3, "%s %s %s\n", builtin_get (idx_ADDTOCOUNTER), name, addst);
  counterval[index] += addnr;

  free (name);
  free (addst);
}
