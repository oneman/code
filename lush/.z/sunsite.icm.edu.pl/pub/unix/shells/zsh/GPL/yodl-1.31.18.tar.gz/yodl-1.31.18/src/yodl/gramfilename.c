
#include "yodl.h"

void
gram_FILENAME ()
{
  lexer_pushstr (cur_input_file);
  lexer ();
}

