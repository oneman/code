
#include "yodl.h"

void 
lexer_pushchar (int ch)
{
  static char
    buf[2];
  char
   *cp;

  if (lexer_pushedp)
    {
      lexer_pushedp--;
      *lexer_pushedp = (char) ch;
    }
  else
    {
      buf[0] = (char) ch;

      if (!lexer_pushed)
	lexer_pushed = xstrdup (buf);
      else
	{
	  cp = xstrdup (buf);
	  cp = str_concat (cp, lexer_pushed);
	  free (lexer_pushed);
	  lexer_pushed = cp;
	}
    }
}
