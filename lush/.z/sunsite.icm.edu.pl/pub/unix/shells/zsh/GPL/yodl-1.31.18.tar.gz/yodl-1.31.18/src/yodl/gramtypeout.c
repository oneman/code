
#include "yodl.h"

void
gram_TYPEOUT ()
{
  char
   *msg;

  msg = gram_parlist (builtin_get (idx_TYPEOUT), 0);
  message (3, "%s %s\n", builtin_get (idx_TYPEOUT), str_short (msg));
  msg = gram_do_expand (msg);
  fprintf (stderr, "%s\n", msg);

  free (msg);
}
