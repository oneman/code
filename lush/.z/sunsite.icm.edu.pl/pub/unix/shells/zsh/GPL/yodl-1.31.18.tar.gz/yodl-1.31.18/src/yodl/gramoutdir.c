
#include "yodl.h"
#include "libc-extension.h"

void
gram_OUTDIR ()
{
  char* dir;
  dir = xstrdup (outfname);
  dirname (dir);

  lexer_pushstr (dir);
  lexer ();
  free (dir);
}

