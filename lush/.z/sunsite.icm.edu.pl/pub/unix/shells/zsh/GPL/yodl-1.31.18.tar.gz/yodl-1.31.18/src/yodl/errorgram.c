
#include "yodl.h"

void
error_gram (char const *rule, char const *msg,...)
{
  va_list args;
  char* symbol;

  /* urg, duplicate code in error_gram */
  if (!lexbuf || !*lexbuf)
    symbol = "<empty>";
  else if (*lexbuf == '\n')
    symbol = "<newline>";
  else
    symbol = lexbuf;

  /*
    use GNU style message
    if only to enable yfte (TM) to take you there.
   */
  gnu_message (rule);

  va_start (args, msg);
  gnu_vmessage (msg, args);
  va_end (args);
  gnu_message ("last parsed symbol: `%s'", symbol);

  exit (1);
}
