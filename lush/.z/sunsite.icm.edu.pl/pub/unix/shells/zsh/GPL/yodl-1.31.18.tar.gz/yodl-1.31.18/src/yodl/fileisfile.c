

#include "yodl.h"

int
file_isfile (char const *name)
{
  struct stat
    statbuf;

  if (!stat (name, &statbuf) &&
      S_ISREG (statbuf.st_mode)
    )
    return (1);

  return (0);

/* Must work too:
   return ( (! stat (name, &statbuf)) && (S_ISREG (statbuf.st_mode)) );
 */
}
