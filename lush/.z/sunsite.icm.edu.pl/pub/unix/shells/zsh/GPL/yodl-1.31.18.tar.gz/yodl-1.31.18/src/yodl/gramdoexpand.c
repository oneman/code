
#include "yodl.h"
#include "libc-extension.h"

void
gram_DOEXPAND (void)
{
  message (3, "%s %s \n", "DOEXPAND", str_short (lexbuf));

  if (!gram_try_expand ())	/* try to expand macro */
    {
      output_string (lexbuf);	/* or literal dump */
      lexer ();
    }
}

