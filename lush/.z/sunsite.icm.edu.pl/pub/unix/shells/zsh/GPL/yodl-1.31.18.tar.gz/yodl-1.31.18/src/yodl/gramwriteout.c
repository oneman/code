
#include "yodl.h"

void
gram_WRITEOUT ()
{
  char* msg;
  char* name;
  FILE* file;

  name = gram_parlist (builtin_get (idx_WRITEOUT), 1);
  msg = gram_parlist (builtin_get (idx_WRITEOUT), 1);
  message (3, "%s %s %s\n", builtin_get (idx_WRITEOUT), str_short (name), 
    str_short (msg));
  name = gram_do_expand (name);

  file = open_file (name, "w");	
  fputs (msg, file);
  fclose (file);

  free (name);
  free (msg);
}
