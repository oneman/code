
#include "yodl.h"

int
gram_hasident (char const *s)
{
  char
   *id = 0;
  char const
   *cp;
  int
    res = 0;

  if (!s || !*s || !isIdentChar (*s))
    return (0);


  for (cp = s; isIdentChar (*cp); cp++)
    id = str_addchar (id, *cp);


  if
    (
      strarr_find (builtin, nbuiltin, id) > -1 ||
      strtab_find (userdef, nuserdef, id) > -1
    )
    res = 1;

  free (id);
  return (res);
}
