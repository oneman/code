
#include "lib.h"

char
 *program_name;

void 
error_setprogname (char const *name)
{
  if (program_name)
    free (program_name);

  program_name = xstrdup (name);
}
