
#include "yodl.h"

void
gram_UNDEFINEMACRO ()
{
  char
   *sym;
  int
    i;

  sym = gram_parlist (builtin_get (idx_UNDEFINEMACRO), 0);
  gram_onename (builtin_get (idx_UNDEFINEMACRO), sym);

  message (3, "undefining macro: %s\n", sym);

#if ! HAVE_HSEARCH_R
  if ((i = strtab_find (userdef, nuserdef, sym)) != -1)
    *userdef[i] = ' ';
#else
  strtab_del (userdef, &nuserdef, sym);
#endif

  free (sym);
}
