
#include "yodl.h"

void 
showchildstatus (int status, char const *cmd)
{
  if (status == -1)
    error_gram ("child program execution",
		"command %s could not be started", cmd);
  else if (status)
    message (0, "Warning: child program %s indicates failure\n", cmd);
}
