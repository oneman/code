
#include "yodl.h"

void
gram_warn (char const *rule, char const *msg,...)
{
  va_list args;
  char* symbol;

  if (!flags.warn)
    return;

  /* urg, duplicate code in error_gram */
  if (!lexbuf || !*lexbuf)
    symbol = "<empty>";
  else if (*lexbuf == '\n')
    symbol = "<newline>";
  else
    symbol = lexbuf;


  /*
    use GNU style message
    if only to enable yfte (TM) to take you there.
   */
  gnu_warning (rule);

  va_start (args, msg);
  gnu_vwarning (msg, args);
  va_end (args);
  gnu_warning ("last parsed symbol: `%s'", symbol);
}

