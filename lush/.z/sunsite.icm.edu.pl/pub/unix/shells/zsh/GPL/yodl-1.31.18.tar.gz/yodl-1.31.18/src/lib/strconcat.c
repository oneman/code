
#include "lib.h"

char *
str_concat (char *str, char const *tail)
{
  int
    slen = str && *str ? strlen (str) : 0, tlen = tail && *tail ? strlen (tail) : 0;

  if (!slen)
    return (xstrdup (tail));
  if (!tlen)
    return (xstrdup (str));

  str = (char *) xrealloc (str, slen + tlen + 1);
  strcpy (str + slen, tail);

  return (str);
}
