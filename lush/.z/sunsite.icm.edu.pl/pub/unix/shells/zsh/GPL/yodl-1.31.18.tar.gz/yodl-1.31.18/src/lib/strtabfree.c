
#include "lib.h"

void 
strarr_free (char **table, int ntable)
{
  int
    i;

  for (i = 0; i < ntable; i++)
    free (table[i]);
  free (table);
}

#if HAVE_HSEARCH_R

#include <search.h>
#include <errno.h>

void 
strtab_free (char **table, int ntable)
{
  struct hsearch_data* hash_table_p = (struct hsearch_data*)table;
  (void)ntable;
  if (!hash_table_p)
    return;
  hdestroy_r (hash_table_p);
  hash_table_p = 0;
}

#endif /* HAVE_HSEARCH_R */
