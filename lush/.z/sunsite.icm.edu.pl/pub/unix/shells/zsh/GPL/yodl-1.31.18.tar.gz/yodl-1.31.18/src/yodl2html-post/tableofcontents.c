
#include "yodl2html-post.h"

void 
tableofcontents (STRINGTAB tab)
{
  FILE
    * f;
  char
    buf[80];

  if (pass)
    {
      f = open_file (tocfname, "r");
      tocheader (tab);
      while (1)
	{
	  fgets (buf, 79, f);
	  if (feof (f))
	    break;
	  output (outf, "%s", buf);
	}
      tocclose ();
      close_file (f);
    }
}
