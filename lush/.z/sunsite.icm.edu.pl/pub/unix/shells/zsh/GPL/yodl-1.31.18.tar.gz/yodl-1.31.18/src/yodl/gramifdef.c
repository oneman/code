





#include "yodl.h"

void
gram_IFDEF ()
{
  char
   *symbol, *truelist, *falselist;
  /* get symbol, true-, falselist */
  symbol = gram_parlist (builtin_get (idx_IFDEF), 0);
  gram_onename (builtin_get (idx_IFDEF), symbol);

  message (3, "%s %s\n", builtin_get (idx_IFDEF), str_short (symbol));

  while (lextok == tok_space ||	/* skip spaces, newlines */
	 lextok == tok_newline
    )
    lexer ();

  truelist = gram_parlist (builtin_get (idx_IFDEF), 0);

  while (lextok == tok_space ||	/* skip spaces, newlines */
	 lextok == tok_newline
    )
    lexer ();

  falselist = gram_parlist (builtin_get (idx_IFDEF), 0);

  lexer_pushstr (lexbuf);	/* push back beyond parlist */

  if (strtab_find (define, ndefine, symbol) > -1 ||
      strarr_find (builtin, nbuiltin, symbol) > -1 ||
      strtab_find (userdef, nuserdef, symbol) > -1 ||
      strtab_find (countername, ncountername, symbol) > -1
    )
    lexer_pushstr (truelist);
  else
    lexer_pushstr (falselist);

  lexer ();			/* prepare next symbol */

  free (symbol);		/* return used memory */
  free (truelist);
  free (falselist);
}
