
#include "yodl.h"

void
gram_POPCHARTABLE ()
{
  char
   *list = gram_parlist (builtin_get (idx_POPCHARTABLE), 0);

  message (3, "%s\n", builtin_get (idx_POPCHARTABLE));
  free (list);

  if (nchartabstack <= 0)
    error_gram (builtin_get (idx_POPCHARTABLE),
		"character table stack underflow, can't pop");

  curchartab = chartabstack[--nchartabstack];
  if (!nchartabstack)
    {
      free (chartabstack);
      chartabstack = 0;
    }
  else
    chartabstack = xrealloc (chartabstack,
			     nchartabstack * sizeof (CHARTAB));
}
