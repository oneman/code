
#include "yodlfixlabels.h"

void 
roffcmd (char **tab, int ntab, int pass)
{
  int
    i;

  if (pass)			/* second pass: expand */
    {
      if (ntab < 4)
	error ("near line %d: incomplete roff command", lineno);

      output (outf, "\n");
      for (i = 2; i < ntab - 1; i++)
	output (outf, "%s ", tab[i]);
      output (outf, "\n");
    }
}
