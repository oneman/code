
#include "yodl.h"

void
gram_NOEXPAND ()
{
  char
   *list;

  list = gram_parlist (builtin_get (idx_NOEXPAND), 1);
  message (3, "%s %s\n", builtin_get (idx_NOEXPAND), str_short (list));

  output_string (list);

  free (list);
}
