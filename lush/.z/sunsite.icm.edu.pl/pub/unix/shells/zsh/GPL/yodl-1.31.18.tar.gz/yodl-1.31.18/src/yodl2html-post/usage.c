
#include "config.h"
#include "yodl2html-post.h"

void 
usage ()
{
  fprintf (stderr,
	   "\n"
	   "Yodl2html-post " TOPLEVEL_VERSION "\n"
	   "Usage: yodl2html-post FILE\n"
	   "Yet OneOther Document Language\n"
	   "\n"
	   "The special tags in yodl's output file are scanned and fixed for HTML usage.\n"
	   "This program shouldn't be run by hand, but e.g. from the yodl2html script.\n"
	   "\n");

  exit (1);
}
