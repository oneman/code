
#include "yodl.h"

void
gram_COUNTERVALUE ()
{
  int
    index;
  char
   *name, buf[80];

  name = gram_parlist (builtin_get (idx_COUNTERVALUE), 0);
  index = gram_findcounter (builtin_get (idx_COUNTERVALUE), name);

  message (3, "%s %s: %d\n", builtin_get (idx_COUNTERVALUE), name,
	   counterval[index]);

  sprintf (buf, "%d", counterval[index]);

  lexer_pushstr (lexbuf);	/* push back symbol beyond parl */
  lexer_pushstr (buf);		/* push back expansion */
  lexer ();			/* prepare next */

  free (name);			/* return memory */
}
