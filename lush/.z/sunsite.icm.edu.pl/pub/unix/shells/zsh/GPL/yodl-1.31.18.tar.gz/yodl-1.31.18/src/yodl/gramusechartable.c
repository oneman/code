
#include "yodl.h"

void
gram_USECHARTABLE ()
{
  int
    index;
  char
   *tabname;

  tabname = gram_parlist (builtin_get (idx_USECHARTABLE), 0);

  message (3, "%s %s\n", builtin_get (idx_USECHARTABLE),
	   tabname && *tabname ? tabname : "zero-state");

  if (!tabname || !*tabname)	/* activate char table */
    curchartab = 0;
  else
    {
      gram_onename (builtin_get (idx_USECHARTABLE), tabname);
      if ((index = strtab_find (chartabname, nchartab, tabname)) == -1)
	error_gram (builtin_get (idx_USECHARTABLE), "no table %s defined",
		    tabname);
      curchartab = chartab + index;
    }

  free (tabname);
}
