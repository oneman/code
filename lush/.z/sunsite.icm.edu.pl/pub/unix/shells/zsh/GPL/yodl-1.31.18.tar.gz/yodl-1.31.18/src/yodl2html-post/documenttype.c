
#include "yodl2html-post.h"

void 
documenttype (STRINGTAB tab)
{
  if (tab.nstr < 4)
    error ("incomplete documenttype tag");

  if (!strcmp (tab.str[3], "article"))
    doctype = type_article;
  else
    doctype = type_book;
}
