
#include "yodl2html-post.h"

void 
labvalue (STRINGTAB t)
{
  int
    i;
  char
   *cp, *labname = 0;

  if (!pass)			/* if first pass: ignore */
    return;

  if (t.nstr < 3)
    error ("incomplete labvalue tag");

  for (i = 3; i < t.nstr; i++)
    labname = str_concat (labname, t.str[i]);
  for (cp = labname; *cp;)	/* remove spaces, if any */
    if (isspace (*cp))
      strcpy (cp, cp + 1);
    else
      cp++;

  for (i = 0; i < nlab; i++)
    if (!strcmp (lab[i].label, labname))
      {
	output (outf, "%s", lab[i].value);
	return;
      }

  warning ("unresolved label: %s", t.str[3]);
  output (outf, "??");
}
