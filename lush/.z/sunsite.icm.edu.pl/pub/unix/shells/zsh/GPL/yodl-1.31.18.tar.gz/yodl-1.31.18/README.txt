
                           README

This is the toplevel README to Yodl

Yodl is a package that implements a pre-document language
and tools to process it.  The idea of Yodl is that you write
up a document in a pre-language, then use the tools (e.g.
yodl2html) to convert it to some final document language.
Current converters are for HTML, ms, man, LaTeX SGML and
texinfo, plus a poor-man's text converter.  Main document
types are "article", "report", "book" and "manpage".  The
Yodl document language is designed to be easy to use and
extensible.

1: VERSIONING

if you have downloaded a

*.pre*

version, then this is version is *not* meant for producing
nice output (but to keep your patchsets up to date).  It
might not even compile.

2: REQUIREMENTS

For the compilation and running of Yodl you need some addi-
tional packages.  Please refer to the installation instruc-
tions.

NOTE: If you downloaded a binary (.rpm or a W95/NT .zip
file), then you don't have to compile Yodl.

3: INSTALLATION

For your convenience, a formatted copy of the INSTALL
instructions are in the toplevel directory, as INSTALL.txt

The process is fairly straightforward, but chances are that
you have to specify directories for TeX to configure
(--enable-tex-dir, --enable-mf-dir)

4: DOCUMENTATION

The real documentation is the directory Documentation/

To generate the pretty-printed docs, you have to run config-
ure first, and then do this:

make doc

You can also simply read the .yo sources.  They are ASCII
text.  The complete documentation is accessible in formatted
form at the website

http://www.cs.uu.nl/people/hanwen/yodl/

5: COMMENTS

Yodl is a long way from finished and polished.  We do appre-
ciate criticism, comments, bugreports, patches, etc.

Please send your e-mail to one of the MAILING LISTS

and not to us personally.  See Documentation/links.yo for
more info.

6: DOZE

If you have received this file as part of a DOS/Window32
distribution (yodl-*.zip), then it is advisable to also
download the source package, since it might contain more
documentation

ftp://ftp.lilypond.org/pub/yodl/ (Europe)

If you decide to build Yodl from source, please read the
INSTALL.txt document first, especially the Windows NT/95
section.

7: CDROM DISTRIBUTIONS

If you have received Yodl on a cdrom, chances are that
development has moved a some patchlevels up.  If possible,
please check the latest version of Yodl before reporting
bugs.
