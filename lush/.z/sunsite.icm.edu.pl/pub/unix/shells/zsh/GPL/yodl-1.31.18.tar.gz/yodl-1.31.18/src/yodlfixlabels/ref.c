
#include "yodlfixlabels.h"

void 
ref (char **tab, int ntab, int pass)
{
  int
    index;

  if (ntab < 4)
    error ("near line %d: ref tag incomplete", lineno);

  if (pass)
    {
      index = strtab_find (lab, nlab, tab[2]);
      if (index < 0)
	warning ("near line %d: unresolved reference %s",
		 lineno, tab[2]);
      else
	output (outf, "%s", num[index]);
    }
}
