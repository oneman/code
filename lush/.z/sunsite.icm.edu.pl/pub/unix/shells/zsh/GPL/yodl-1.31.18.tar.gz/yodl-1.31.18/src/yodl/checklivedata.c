
#include "yodl.h"

int
check_live_data (char const *macro, char const *cmd)
{
  switch (livedata)
    {
    case 0:
      message (0, "%s %s: not executed\n",
	       macro, str_short (cmd));
      return (0);

    case 1:
      if (!userconfirm (cmd))
	return (0);
      /* and fall through to : */

    case 2:
      message (0, "%s %s\n", macro, str_short (cmd));
      return (1);

    default:
      return (1);
    }

  return (0);			/* to satisfy prototype, not really needed */
}
