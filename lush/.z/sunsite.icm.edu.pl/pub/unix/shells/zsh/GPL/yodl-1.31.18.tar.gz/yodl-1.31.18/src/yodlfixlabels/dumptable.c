
#include "yodlfixlabels.h"

void 
dumptable (char **tab, int start, int ntab)
{
  int
    i;

  for (i = start; i < ntab; i++)
    {
      output (outf, "%s", tab[i]);
      if (i < ntab - 1)
	fputc (' ', outf);
    }
}
