
#include "yodl.h"

void
gram_UNDEFINESYMBOL ()
{
  char
   *sym;

  sym = gram_parlist (builtin_get (idx_UNDEFINESYMBOL), 0);
  gram_onename (builtin_get (idx_UNDEFINESYMBOL), sym);

  message (3, "%s %s\n", builtin_get (idx_UNDEFINESYMBOL), sym);

  strtab_del (define, &ndefine, sym);
  free (sym);
}
