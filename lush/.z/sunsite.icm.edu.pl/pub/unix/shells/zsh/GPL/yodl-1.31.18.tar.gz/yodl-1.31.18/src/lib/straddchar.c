
#include "lib.h"

char *
str_addchar (char *buf, int ch)
{
  int
    index;

  index = buf ? strlen (buf) : 0;

  buf = (char *) xrealloc (buf, index + 2);
  buf[index] = (char) ch;
  buf[index + 1] = '\0';

  return (buf);

}
