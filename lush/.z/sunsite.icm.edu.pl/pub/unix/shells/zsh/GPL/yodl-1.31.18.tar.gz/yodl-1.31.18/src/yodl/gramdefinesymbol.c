
#include "yodl.h"

void
gram_DEFINESYMBOL ()
{
  char
   *sym;

  sym = gram_parlist (builtin_get (idx_DEFINESYMBOL), 0);

  message (3, "%s %s\n", builtin_get (idx_DEFINESYMBOL), sym);

  gram_onename (builtin_get (idx_DEFINESYMBOL), sym);

  if (strtab_find (define, ndefine, sym) >= 0)
    error_gram (builtin_get (idx_DEFINESYMBOL),
		"symbol %s already defined", sym);

  define = strtab_add (define, &ndefine, sym);

  free (sym);
}
