

#include "yodl2html-post.h"

void 
tocheader (STRINGTAB tab)
{
  int
    i;

  if (tab.nstr < 4)
    error ("incomplete tableofcontents tag");
  output (outf, "<h1>");
  for (i = 3; i < tab.nstr; i++)
    output (outf, "%s", tab.str[i]);
  output (outf, "</h1><p></p>\n");
}
