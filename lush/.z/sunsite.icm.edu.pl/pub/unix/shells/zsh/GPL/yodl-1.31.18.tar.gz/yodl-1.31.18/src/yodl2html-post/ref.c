
#include "yodl2html-post.h"

void 
ref (STRINGTAB t)
{
  int
    i;
  char
   *cp, *refname = 0;

  if (!pass)			/* if first pass: ignore */
    return;

  if (t.nstr < 3)
    error ("incomplete ref tag");

  for (i = 3; i < t.nstr; i++)
    refname = str_concat (refname, t.str[i]);
  for (cp = refname; *cp;)	/* remove spaces, if any */
    if (isspace (*cp))
      strcpy (cp, cp + 1);
    else
      cp++;

  for (i = 0; i < nlab; i++)
    if (!strcmp (lab[i].label, refname))
      {
	output (outf, "<a href=\"%s#%s\">%s</a>",
		lab[i].fname,
		lab[i].label,
		lab[i].value);
	return;
      }

  warning ("unresolved label: %s", t.str[3]);
  output (outf, "??");
}
