
#include "yodl.h"

void
gram_STARTDEF ()
{
  char
   *arg;

  arg = gram_parlist (builtin_get (idx_STARTDEF), 0);
  in_def++;

  message (3, "%s now DEF level %d\n", builtin_get (idx_STARTDEF), in_def);

  free (arg);
}
