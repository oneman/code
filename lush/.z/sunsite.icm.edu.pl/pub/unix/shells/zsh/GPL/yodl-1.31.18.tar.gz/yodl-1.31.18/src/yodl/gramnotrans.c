
#include "yodl.h"

void
gram_NOTRANS ()
{
  char
   *list;
  CHARTAB
    * old_curchartab;

  list = gram_parlist (builtin_get (idx_NOTRANS), 1);
  message (3, "%s %s\n", builtin_get (idx_NOTRANS), str_short (list));

  old_curchartab = curchartab;
  curchartab = 0;
  output_string (list);
  curchartab = old_curchartab;

  free (list);
}
