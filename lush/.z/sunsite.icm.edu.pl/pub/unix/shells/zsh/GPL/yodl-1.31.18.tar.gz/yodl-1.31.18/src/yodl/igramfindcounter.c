

#include "yodl.h"

int
gram_findcounter (char const *rule, char const *name)
{
  int
    index;

  gram_onename (rule, name);

  if ((index = strtab_find (countername, ncountername, name)) == -1)
    error_gram (rule, "no counter %s defined", name);

  return (index);
}
