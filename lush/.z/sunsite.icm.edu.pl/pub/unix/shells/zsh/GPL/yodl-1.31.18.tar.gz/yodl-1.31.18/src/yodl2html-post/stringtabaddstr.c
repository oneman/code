
#include "yodl2html-post.h"

void 
stringtab_addstr (STRINGTAB * tab, char const *s)
{
  tab->nstr++;
  tab->str = (char **) xrealloc (tab->str, (tab->nstr) * sizeof (char *));
  tab->str[tab->nstr - 1] = xstrdup (s);
}
