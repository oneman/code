
#include "yodl2html-post.h"

void 
chapterlinks ()			/* set links to next/prev chap */
{				/* and table of contents */

  if (outf_count < 1 ||		/* no links in table of contents */
      doctype == type_article	/* or in articles */
    )
    return;

  output (outf, "<hr>\n"
	  "<ul>\n");
  if (outf_count < outf_max)
    output (outf, "    <li> <a href=\"%s\">Next chapter</a>\n",
	    basename (outputfilename (outf_count + 1)));
  if (outf_count > 1)
    output (outf, "    <li> <a href=\"%s\">Previous chapter</a>\n",
	    basename (outputfilename (outf_count - 1)));
  output (outf, "    <li> <a href=\"%s\">Table of contents</a>\n",
	  fbase);

  output (outf, "</ul>\n"
	  "<hr>\n"
    );
}
