
#include "yodl.h"

int
gram_getchar ()			/* return argument of CHAR() */
{
  static char
    buf[2];
  char
   *list = gram_parlist (builtin_get (idx_CHAR), 0);
  char* express = list;

  buf[0] = 0;
  while (express)
    {
      if (isdigit ((int)*express))
	buf[0] += (char) gram_onenumber (builtin_get (idx_CHAR), express);
      else if (strlen (express) == 1)
	buf[0] += *express;
      else
	error_gram (builtin_get (idx_CHAR),
		    "argument must be either a number or a single character");
      express = strchr (express, '+');
      if (express)
	express++;
    }

  message (3, "%s %s\n", builtin_get (idx_CHAR), list);
  free (list);
  return (buf[0]);
}

