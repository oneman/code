
#include "yodl.h"

void
gram_ATEXIT ()
{
  char
   *list = gram_parlist (builtin_get (idx_ATEXIT), 0);

  message (3, "%s %s\n", builtin_get (idx_ATEXIT), str_short (list));

  atexit_strings = strtab_add (atexit_strings, &natexit_strings, list);

  free (list);
}
