
#include "yodl.h"

void
gram_SETCOUNTER ()
{
  int
    index;
  char
   *name, *value;

  /* read counter name */
  name = gram_parlist (builtin_get (idx_SETCOUNTER), 0);
  index = gram_findcounter (builtin_get (idx_SETCOUNTER), name);

  while (lextok == tok_space ||	/* skip spaces, newlines */
	 lextok == tok_newline
    )
    lexer ();
  /* read counter value */
  value = gram_parlist (builtin_get (idx_SETCOUNTER), 1);

  message (3, "%s %s to %s\n", builtin_get (idx_SETCOUNTER), name, value);
  counterval[index] = gram_onenumber (builtin_get (idx_SETCOUNTER), value);

  free (name);
  free (value);
}
