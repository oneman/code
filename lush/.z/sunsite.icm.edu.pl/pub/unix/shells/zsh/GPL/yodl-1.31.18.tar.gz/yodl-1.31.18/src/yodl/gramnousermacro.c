
#include "yodl.h"

void
gram_NOUSERMACRO ()
{
  char
   *cp,				/* tmp var */
   *list;			/* list of no-user macros */

  list = gram_parlist (builtin_get (idx_NOUSERMACRO), 0);
  message (3, "%s %s\n", builtin_get (idx_NOUSERMACRO), str_short (list));

  cp = strtok (list, " :,;\t\n");
  while (cp)
    {
      message (4, "%s %s\n", builtin_get (idx_NOUSERMACRO), cp);
      nousermacro = strtab_add (nousermacro, &nnousermacro, cp);
      cp = strtok (NULL, " :,;\t\n");
    }
}
