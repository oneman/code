#include "yodl.h"

int
isIdentChar (int ch)
{
  return (isalpha (ch));
}
