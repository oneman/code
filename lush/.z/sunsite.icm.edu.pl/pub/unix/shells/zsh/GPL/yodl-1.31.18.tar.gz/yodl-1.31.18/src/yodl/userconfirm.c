
#include "yodl.h"

int 
userconfirm (char const *cmd)
{
  int
    ch;

  fprintf (stderr, "Warning, live data \"%s\"\n"
	   "Run command (y/n)? ", cmd);

  while (1)
    {
      if ((ch = getchar ()) == 'y')
	return (1);
      else if (ch == 'n')
	return (0);
    }
}
