
#define EXTERN
#include "yodl2html-post.h"

int 
main (int argc, char **argv)
{
  if (argc != 2)		/* check arguments */
    usage ();

  fname = argv[1];
  fbase = xstrdup (basename (fname));

  init ();			/* global initializations */

  lineno = 1;			/* pass one */
  yyparse ();
  close_file (tocf);
  tocf = 0;

  lineno = 1;			/* pass two */
  outf_count = 0;
  lastlabelnr = 0;
  fseek (yyin, 0, SEEK_SET);
  yyrestart (yyin);
  pass++;
  yyparse ();

  chapterlinks ();		/* add links to last chapter */

  output (outf,
	  "</body>\n"		/* FBB 971025, ATEXIT(...</body>)from
				   aux-macros.in removed */
	  "</html>\n");		/* FBB 971025 */

  cleanup (0);
  return (0);
}
