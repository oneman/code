

#include "yodl2html-post.h"

int 
toclevel (char *s)
{
  int
    res_val;

  if (strcmp (s, "chap") == 0)
    {
      res_val = TOC_CHAPTER;
    }
  else if (strcmp (s, "sect") == 0)
    {
      res_val = TOC_SECTION;
    }
  else if (strcmp (s, "ssect") == 0)
    {
      res_val = TOC_SUBSECT;
    }
  else if (strcmp (s, "sssect") == 0)
    {
      res_val = TOC_SUBSUBSECT;
    }
  else
    {
      res_val = 0;
    }

  return res_val;
}
