#!@SHELL@
# yodl2tely-post.sh

# assuming .tely is going to be document *source*,
# don't fill in all @node references explicitely.
# yodl2texinfo-post --simple-nodes $*

# urg: 
# makeinfo's (3.12s) automatic node referencing is still rather flaky
# better fill in all references ourselves
yodl2texinfo-post $*
exit $?
