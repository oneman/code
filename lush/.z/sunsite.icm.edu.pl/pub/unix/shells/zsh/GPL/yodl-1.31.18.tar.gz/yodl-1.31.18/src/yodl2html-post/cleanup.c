

#include "yodl2html-post.h"

void 
cleanup (int err)
{
  int
    i;

  fclose (yyin);
  fclose (outf);
  if (tocf)
    fclose (tocf);

  if (err)
    rename (inputfile, fname);

  for (i = 0; i < ntempfiles; i++)
    unlink (tempfiles[i]);
}
