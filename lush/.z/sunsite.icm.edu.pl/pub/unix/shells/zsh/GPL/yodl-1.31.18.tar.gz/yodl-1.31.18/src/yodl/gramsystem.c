
#include "yodl.h"

void
gram_SYSTEM ()
{
  char
   *cmd;

  cmd = gram_parlist (builtin_get (idx_SYSTEM), 1);
  message (3, "%s %s\n", builtin_get (idx_SYSTEM), str_short (cmd));
  cmd = gram_do_expand (cmd);
  if (check_live_data (builtin_get (idx_SYSTEM), cmd))
    showchildstatus (system (cmd), cmd);

  free (cmd);
}
