
#include "yodlfixlabels.h"

void 
runpass (int pass)
{
  char
    buf[2000];			/* input buffer */

  while (1)
    {
      if (!fgets (buf, 1999, inf))	/* read one line */
	break;

      lineno++;			/* update line number */

      handleline (buf, pass);	/* process the line */
    }
}
