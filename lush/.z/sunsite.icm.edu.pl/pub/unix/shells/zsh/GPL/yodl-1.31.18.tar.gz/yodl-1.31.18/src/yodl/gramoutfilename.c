
#include "yodl.h"

void
gram_OUTFILENAME ()
{
  lexer_pushstr (outfname);
  lexer ();
}

