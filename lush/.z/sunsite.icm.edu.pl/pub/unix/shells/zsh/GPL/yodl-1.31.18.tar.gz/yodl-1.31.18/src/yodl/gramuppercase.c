
#include "yodl.h"

void
gram_UPPERCASE ()
{
  char
   *string, *max;
  int
    maxlen, i;

  string = gram_parlist (builtin_get (idx_UPPERCASE), 1);
  while (lextok == tok_space ||
	 lextok == tok_newline
    )
    lexer ();
  max = gram_parlist (builtin_get (idx_UPPERCASE), 1);
  maxlen = gram_onenumber (builtin_get (idx_UPPERCASE), max);

  /* urg: cast to int */
  if (maxlen < 1 || maxlen > (int)strlen (string))
    maxlen = strlen (string);
  for (i = 0; i < maxlen; i++)
    string[i] = toupper (string[i]);

  lexer_pushstr (string);

  free (string);
  free (max);
}
