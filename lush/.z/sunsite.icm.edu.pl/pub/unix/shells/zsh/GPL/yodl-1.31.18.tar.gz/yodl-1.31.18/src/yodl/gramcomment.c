
#include "yodl.h"

void
gram_COMMENT ()
{
  char
   *list = gram_parlist (builtin_get (idx_COMMENT), 0);

  message (3, "%s %s\n", builtin_get (idx_COMMENT), str_short (list));
  free (list);
}
