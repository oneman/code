
#include "yodl2html-post.h"

void 
stringtab_reset (STRINGTAB * tab)
{
  tab->nstr = 0;
  tab->str = 0;
}
