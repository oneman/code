
#include "config.h"
#include "yodlfixlabels.h"

void 
tableofcontents (int pass)
{
  int
    i, j;
  char
  **onetoc;
  int
    nonetoc;

  if (!pass)			/* first pass: no actions */
    return;

  /* second pass: paste in toc */
  if (ntoc)
    {
      output (outf, "\n");
      for (i = 0; i < ntoc; i++)
	{
	  onetoc = toc[i];
	  nonetoc = tocsize[i];
	  for (j = 0; j < nonetoc; j++)
	    if (!strcmp (onetoc[j], TOCCOMMAND))
	      output (outf, "\n%s\n", onetoc[++j]);
	    else
	      output (outf, "%s ", onetoc[j]);
	  output (outf, "\n");

	  strtab_free (onetoc, nonetoc);
	}
    }
  free (toc);
  free (tocsize);
}
