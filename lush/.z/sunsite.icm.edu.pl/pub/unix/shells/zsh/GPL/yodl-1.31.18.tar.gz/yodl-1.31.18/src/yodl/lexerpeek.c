
#include "yodl.h"

int 
lexer_peek ()
{
  int
    ch;

  ch = lexer_getc ();
  lexer_pushchar (ch);
  return (ch);
}
