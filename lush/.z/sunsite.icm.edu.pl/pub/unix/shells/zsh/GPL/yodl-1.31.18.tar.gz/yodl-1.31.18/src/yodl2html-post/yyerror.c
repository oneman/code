

#include "yodl2html-post.h"

int 
yyerror (char const *msg)
{
  error ("syntax error in input at line %d, current symbol: %s",
	 lineno, yytext);
  return (0);
}
