
#include "yodl.h"

void
gram_CHDIR ()
{
  char
   *dirname;

  dirname = gram_parlist (builtin_get (idx_CHDIR), 0);
  gram_onename (builtin_get (idx_CHDIR), dirname);
  message (2, "changing to dir: %s\n", dirname);

  if (chdir (dirname))
    error_gram (builtin_get (idx_CHDIR), "cannot chdir to %s: %s",
		dirname, strerror (errno));

  free (dirname);
}
