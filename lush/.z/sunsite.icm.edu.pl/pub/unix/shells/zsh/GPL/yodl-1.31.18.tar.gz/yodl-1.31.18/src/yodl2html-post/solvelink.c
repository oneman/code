
#include "yodl2html-post.h"

void 
solvelink (STRINGTAB t)
{
  int
    i;
  char
   *labname = 0, *cp;

  if (!pass)			/* if first pass: ignore */
    return;

  if (t.nstr < 3)
    error ("incomplete solvelink tag");

  for (i = 3; i < t.nstr; i++)	/* make full label of substrings */
    labname = str_concat (labname, t.str[i]);

  for (cp = labname; *cp;)	/* remove spaces, if any */
    if (isspace (*cp))
      strcpy (cp, cp + 1);
    else
      cp++;

  for (i = 0; i < nlab; i++)
    if (!strcmp (lab[i].label, labname))
      {
	output (outf, "%s#%s",
		lab[i].fname,
		lab[i].label);
	return;
      }

  warning ("unresolved label: %s", labname);
  output (outf, "??");
}
