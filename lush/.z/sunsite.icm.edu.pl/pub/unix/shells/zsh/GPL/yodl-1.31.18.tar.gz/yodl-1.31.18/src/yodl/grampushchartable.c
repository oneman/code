


#include "yodl.h"

void
gram_PUSHCHARTABLE ()
{
  int
    index;
  char
   *tabname;
  CHARTAB
    * newtab;

  tabname = gram_parlist (builtin_get (idx_PUSHCHARTABLE), 0);

  message (3, "%s %s\n", builtin_get (idx_PUSHCHARTABLE),
	   tabname && *tabname ? tabname : "zero-state");

  if (!tabname || !*tabname)	/* find char table */
    newtab = 0;
  else
    {
      gram_onename (builtin_get (idx_PUSHCHARTABLE), tabname);
      if ((index = strtab_find (chartabname, nchartab, tabname)) == -1)
	error_gram (builtin_get (idx_PUSHCHARTABLE), "no table %s defined",
		    tabname);
      newtab = chartab + index;
    }

  chartabstack = xrealloc (chartabstack,	/* push table */
			   (nchartabstack + 1) * sizeof (CHARTAB));
  chartabstack[nchartabstack++] = curchartab;
  curchartab = newtab;

  free (tabname);
}
