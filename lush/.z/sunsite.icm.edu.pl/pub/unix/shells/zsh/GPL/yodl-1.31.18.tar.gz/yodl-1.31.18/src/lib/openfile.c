
#include "lib.h"

FILE *
open_file (char const *name, char const *mode)
{
  FILE
    * ret;

  if (!strcmp (name, "-"))	/* stdin/out? */
    ret = (*mode == 'r') ? stdin : stdout;
  else /* real filename ? */ 
    { 
      if (!(ret = fopen (name, mode)))
        {
	  if (*mode == 'r')
	    error ("can't open file: `%s'", name);
	  else
	    error ("can't create file: `%s'", name);
	}
    }

  return (ret);
}
