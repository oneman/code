
#include "yodl.h"

void
gram_USECOUNTER ()
{
  char
   *name;
  int
    index;
  char
    buf[80];

  name = gram_parlist (builtin_get (idx_USECOUNTER), 0);
  index = gram_findcounter (builtin_get (idx_USECOUNTER), name);

  (counterval[index])++;

  message (3, "%s %s: now %d\n",
	   builtin_get (idx_USECOUNTER), name, counterval[index]);

  lexer_pushstr (lexbuf);	/* push back beyond parlist */
  sprintf (buf, "%d", counterval[index]);
  lexer_pushstr (buf);		/* push back expansion */

  lexer ();			/* prepare next symbol */

  free (name);
}
