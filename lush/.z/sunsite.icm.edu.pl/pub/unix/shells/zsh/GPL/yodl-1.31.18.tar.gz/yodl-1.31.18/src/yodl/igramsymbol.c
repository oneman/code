

#include "config.h"
#include "yodl.h"

#include "builtins.c"

struct Builtin *
builtin_find (char const *name)
{
  struct Builtin *b = builtins;
  while (b->func)
    {
      if (!strcmp (name, b->name))
	return b;
      b++;
    }
  return 0;
}

#if 0
int 
builtin_idx (char const* name)
{
  int i = 0;
  struct Builtin *b = builtins;
  while (b->func)
    {
      if (!strcmp (name, b->name))
	return i;
      b++;
      i++;
    }
  return 0;
}
#endif

#if 0

#if !  HAVE_HSEARCH_R

char*
builtin_get (int i)
{
  return builtin[i];
}

#else /* HAVE_HSEARCH_R */

char*
builtin_get (int i)
{
#if 0
  return strtab_find (builtin, nbuiltin, builtins[i].name);
#endif
  return builtins[i].name;
}

#endif /* HAVE_HSEARCH_R */

#endif

void
gram_symbol ()			/* handle SYM(blabla) */
{
  int symindex = strarr_find (builtin, nbuiltin, lexbuf);

  if (symindex >= 0)            /* if builtin function: */
    {
      lexer ();			/* prepare symbol */
      builtins[symindex].func();	/* start function */
    }
  else
    /* user-defined ? */
    {
      /* gram_EXPAND (); */
      if (!gram_try_expand ())	/* try to expand macro */
	{
	  output_string (lexbuf);	/* or literal dump */
	  lexer ();
	}
    }
}

