
#include "lib.h"
#include <stdarg.h>
#include <unistd.h>

extern char
 *program_name;

void 
error (char const *fmt,...)
{
  va_list
    args;

  fputc ('\n', stderr);
  if (program_name)
    fprintf (stderr, "%s ", program_name);

  va_start (args, fmt);
  fputs ("fatal error: ", stderr);
  vfprintf (stderr, fmt, args);
  fputc ('\n', stderr);

  exit (1);
}
