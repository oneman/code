
#include "lib.h"
#include <string.h>
#include <stdio.h>

extern char
  out_of_memory[];

char *
xstrdup (char const *s)
{
  char
   *ret;

  if (!s || !*s)
    ret = strdup ("");
  else
    ret = strdup (s);

  if (!ret)
    error (out_of_memory);

  return (ret);
}
