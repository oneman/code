
#include "yodl2html-post.h"

void 
stringtab_setstr (STRINGTAB * tab, char const *s)
{
  stringtab_reset (tab);
  stringtab_addstr (tab, s);
}
