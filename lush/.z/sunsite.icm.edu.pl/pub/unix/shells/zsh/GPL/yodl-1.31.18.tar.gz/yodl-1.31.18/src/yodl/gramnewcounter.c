
#include "yodl.h"

void
gram_NEWCOUNTER ()
{
  char
   *name;

  name = gram_parlist (builtin_get (idx_NEWCOUNTER), 0);
  gram_onename (name, builtin_get (idx_NEWCOUNTER));
  message (3, "%s %s\n", builtin_get (idx_NEWCOUNTER), str_short (name));

  if (strtab_find (countername, ncountername, name) != -1)
    error_gram (builtin_get (idx_NEWCOUNTER),
		"counter `%s\' already exists", name);

  countername = strtab_add (countername, &ncountername, name);
  counterval = (int *) xrealloc (counterval, ncountername * sizeof (int));
  counterval[ncountername - 1] = 0;

  free (name);
}
