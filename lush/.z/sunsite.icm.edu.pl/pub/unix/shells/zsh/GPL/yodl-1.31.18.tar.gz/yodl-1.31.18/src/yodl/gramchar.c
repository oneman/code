
#include "yodl.h"

void
gram_CHAR ()
{
  CHARTAB
    * old_chartab;
  static char
    buf[2];

  old_chartab = curchartab;
  curchartab = 0;
  buf[0] = (char) gram_getchar ();
  output_string (buf);
  curchartab = old_chartab;
}
