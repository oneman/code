
#include "yodl.h"

void
gram_ENDDEF ()
{
  char
   *arg;

  arg = gram_parlist (builtin_get (idx_ENDDEF), 0);
  in_def--;

  message (3, "%s now DEF level %d\n", builtin_get (idx_ENDDEF), in_def);

  free (arg);
}
